</div><!-- /.row -->

</div><!-- /.container -->

<footer class="blog-footer">
<?php
            wp_nav_menu( array(
                'theme_location' => 'footer-menu',
                'menu_class' => 'footer_menu_class'
            ));
        ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>
