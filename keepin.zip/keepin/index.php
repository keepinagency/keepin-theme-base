<?php 
    get_header(); 
    require("content.php");
    get_footer();
?>